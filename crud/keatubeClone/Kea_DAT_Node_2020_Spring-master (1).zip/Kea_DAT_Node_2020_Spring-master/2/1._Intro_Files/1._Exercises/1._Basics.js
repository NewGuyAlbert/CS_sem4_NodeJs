// --------------------------------------
// Variables, strings, numbers, floats
// --------------------------------------
// Exercise 1 - Console and variables

var firstName = "Anders";
var lastName = "Latif";
// EXERCISE
// show in the console
// My first name is Anders and my last name is Latif

console.log("My first name is", firstName, "my last name is", lastName);


// --------------------------------------
// Exercise 2 - Numbers and Strings

var year = "2019abc123";
var number = 1;

// Add the year plus the number
// The result should be 2020
// You cannot touch line 1 or 2

//var newYear = parseInt(year) + number;

console.log(parseInt(year));

// var newYear = Number(year) + number;

// console.log(newYear);

// console.log(+year + number);

// --------------------------------------

