var name = "Jakub";

console.log("hello", name);

var age = 123;

console.log("I'm", age, "years old");

var anotherName = 'Al';



